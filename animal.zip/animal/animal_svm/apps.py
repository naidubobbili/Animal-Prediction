from django.apps import AppConfig


class AnimalSvmConfig(AppConfig):
    name = 'animal_svm'
